var students = [
    { name: "Alice", marks: 90 },
    { name: "Bob", marks: 75 },
    { name: "Charlie", marks: 85 }
];
students.forEach(function (s) {
    console.log("Name: ".concat(s.name, ", Marks: ").concat(s.marks));
});
