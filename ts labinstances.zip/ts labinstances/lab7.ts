function greetUser(name: string, title: string = "Mr./Ms."): string {
  return `Hello, ${title} ${name}!`;
}

console.log(greetUser("Alex"));
console.log(greetUser("Alex", "Dr."));

function addNumbers(a: number, b: number): number {
  return a + b;
}
console.log(addNumbers(4, 6));