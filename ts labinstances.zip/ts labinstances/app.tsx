import UserStatus from "./new";

function App() {
  return (
    <div>
      <h1>My First TypeScript React App</h1>
      <UserStatus />
    </div>
  );
}

export default App;