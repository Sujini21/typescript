interface User {
  readonly id: number;
  name: string;
  age?: number;
}

const user1: User = {
  id: 101,
  name: "Alex",
  age: 25
};

console.log(user1);
user1.name = "Sam";
console.log(user1);