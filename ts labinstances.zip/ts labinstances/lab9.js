function move(direction) {
    console.log("Moving ".concat(direction));
}
move("up");
move("left");
function formatValue(value) {
    if (typeof value === "string") {
        console.log(value.toUpperCase());
    }
    else {
        console.log(Math.round(value));
    }
}
formatValue("hello");
formatValue(4.7);
