var a = 100;
// a = "Finish"; ❌ Error: string not assignable to number
console.log(a);
