function printPoint(point) {
    console.log("Point coordinates: x=".concat(point.x, ", y=").concat(point.y));
}
printPoint({ x: 10, y: 20 });
