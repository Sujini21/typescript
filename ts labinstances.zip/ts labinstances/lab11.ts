interface Student {
  name: string;
  marks: number;
}

const students: Student[] = [
  { name: "Alice", marks: 90 },
  { name: "Bob", marks: 75 },
  { name: "Charlie", marks: 85 }
];

students.forEach(s => {
  console.log(`Name: ${s.name}, Marks: ${s.marks}`);
});