function greetUser(name, title) {
    if (title === void 0) { title = "Mr./Ms."; }
    return "Hello, ".concat(title, " ").concat(name, "!");
}
console.log(greetUser("Alex"));
console.log(greetUser("Alex", "Dr."));
function addNumbers(a, b) {
    return a + b;
}
console.log(addNumbers(4, 6));
