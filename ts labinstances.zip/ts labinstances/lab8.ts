type Point = {
  x: number;
  y: number;
};

function printPoint(point: Point): void {
  console.log(`Point coordinates: x=${point.x}, y=${point.y}`);
}

printPoint({ x: 10, y: 20 });