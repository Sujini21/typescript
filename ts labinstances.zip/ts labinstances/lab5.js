function greetUser(name, title) {
    if (title === void 0) { title = "Mr./Ms."; }
    return "Hello, ".concat(title, " ").concat(name, "!");
}
console.log(greetUser("Alex"));
console.log(greetUser("Alex", "Dr."));
var add = function (a, b) { return a + b; };
var multiply = function (a, b) { return a * b; };
console.log(add(5, 3));
console.log(multiply(5, 3));
