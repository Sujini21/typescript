import React from "react";

type MessageProps = {
  isLoggedIn: boolean;
};

const Message: React.FC<MessageProps> = ({ isLoggedIn }) => {
  return (
    <div>{isLoggedIn ? <h2>Welcome back!</h2> : <h2>Please log in</h2>}</div>
  );
};

export default Message;
